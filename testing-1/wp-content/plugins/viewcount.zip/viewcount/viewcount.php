<?php
/* Plugin name: View Count
*plugin url:https://www.pixlerLab.com
*Author :Deep
*Author uri:https://www.pixlerlab.com
*Description:Check Viewer in site
*/
defined('ABSPATH') ||die('Nice Try');
//basename(parse_url('http://localhost/testing/testing-1/wp-admin/admin.php?page=viewer-count', PHP_URL_PATH));
//-----------------------------------------------------------------------------//
// add menu and submenu in plugin adminmenu
add_action('admin_menu', 'view_count_admin_1');
 
function view_count_admin_1(){
    add_menu_page( 'Viewer Count', 'Viewer Count', 'manage_options', 'viewer-count','view_count_admin_2','dashicons-admin-users',100);// main menu
    add_submenu_page('viewer-count','Viewer Count 2','Viewer Count 2','manage_options','viewer-count-2','viewer_count_2');// submenu in the plugin
}  
//main menu function 
function view_count_admin_2(){
    include('includes/count.php');
}
// submenu function
function viewer_count_2(){
    include('includes/count2.php');
}


//-------------------------------------------------------------------------------//


//plugin activation and deactivatio table create and delete 
register_activation_hook( __FILE__, 'viewr_create_table' );
function viewr_create_table()
{      
  global $wpdb; 
  $db_table_name = $wpdb->prefix . 'viewer_count';  // add prefixed and create viewer_count
  $charset_collate = $wpdb->get_charset_collate();
       $sql = "CREATE TABLE " . $db_table_name . " (
        id int(11) NOT NULL auto_increment,
                `pageid` int(11) NOT NULL,
               `pagetitle` varchar(255) NOT NULL,
               `viewer` bigint(20) NOT NULL,
               `country` varchar(200) NOT NULL,
                `city` varchar(200) NOT NULL,
                `zip` bigint(20) NOT NULL,
                `ipaddress` varchar(200) NOT NULL,
                PRIMARY KEY (id)
                UNIQUE (ipaddress)
        ) $charset_collate;";
   require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
   dbDelta( $sql.$sql1);
  
   add_option( 'test_db_version', $test_db_version );
} 
 // table delate in database for plugin deactivation
 register_deactivation_hook( __FILE__, 'viewr_delete_table' );
 function viewr_delete_table(){
    global $wpdb; 
    $db_table_name = $wpdb->prefix . 'viewer_count'; 
    $sql = "drop table $db_table_name"; 
    $wpdb->query($sql);
 }

 //-------------------------------------------------------------------------------//

 
// add css and js in plugin 
 add_action( 'admin_enqueue_scripts', 'ci_add_cssjs_styles' );
 function ci_add_cssjs_styles() {
   wp_register_style( 'ci-comment-custom-styles', plugins_url( '/', __FILE__ ) . 'assets/style.css' );
   wp_enqueue_style( 'dashicons' );
   wp_enqueue_style( 'ci-comment-custom-styles' );
 }
 // add script file in plugin 
 add_action('admin_enqueue_scripts','plugin_scripts');
 function plugin_scripts(){
   wp_enqueue_script('ci-comment-custom-scripts', plugins_url( '/', __FILE__ ) . 'assets/app.js' ,array('jquery'),false,true);
//    wp_enqueue_script('ci-comment-custom-scripts', plugins_url( '/', __FILE__ ) . 'assets/model.js' ,array('jquery'),false,true);
//    wp_enqueue_script('ci-comment-custom-scripts', plugins_url( '/', __FILE__ ) . 'assets/model1.js' ,array('jquery'),false,true);
//    wp_enqueue_script('ci-comment-custom-scripts', plugins_url( '/', __FILE__ ) . 'assets/model3.js' ,array('jquery'),false,true);

 }

 // add bootstrapp file in plugin
 add_action('admin_enqueue_scripts', 'wpbootstrap_enqueue_styles');
 function wpbootstrap_enqueue_styles() {
    wp_enqueue_style( 'bootstrap', 'http://localhost/testing/testing-1/wp-content/plugins/viewcount/assets/bootstrapfile.css' );
    }
   


 loadIp();
 // Get IP Details from user 
function loadIp(){
$save =0;    
 $ch=curl_init();
 curl_setopt($ch,CURLOPT_URL,"http://ip-api.com/json");
 curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
  $result=curl_exec($ch);
 $result = json_decode($result);
 
if($result->status =='success'){  
 global $wpdb; 
$db_table_name = $wpdb->prefix . 'viewer_count';
 $wpdb->insert($db_table_name, array(
    // 'status'=>$result->status,
    'country'=>$result->country,
    // 'region'=>$result->regionName,
    'city'=>$result->city,
    'zip'=>$result->zip,
    'ipaddress'=>$result->query
));
}
}
?>

<?php
 // get data throw api  in plugin
// $url='http://localhost/wordpress_new/';

//   function wp_remote_get( $url,register_post_type( $post_type:string,[
//     'label' =>
//     'public' =>
//     'capability' =>
//   ] 
//     )
// ) 
// {
//  	$http = _wp_http_get_object();
//  	return $http->get( $url, $args );
//  }


