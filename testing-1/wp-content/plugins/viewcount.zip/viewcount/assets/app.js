// window.onload = function(){
//     document.forms['member_signup'].submit();
//   }
  // shoe on edit button data
  $(document).on("click",".showdiv" ,function(){
    $("#model").show();
  });
  //on click close hide model box
  $(document).on("click","#close" ,function(){
    $("#model").hide();
  });
 