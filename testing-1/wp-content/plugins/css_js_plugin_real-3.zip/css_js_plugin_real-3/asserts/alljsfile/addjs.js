function allcolor(){
    document.getElementById("setcolortext").style.setProperty('padding-top', '1000px');
    //document.getElementById("setcolortext").style.color = "blue";
    
}
