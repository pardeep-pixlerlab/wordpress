<?php

// delete data  data in database  
 if (isset($_GET['delete'])) {
    global $wpdb; 
     $db_table_name = $wpdb->prefix . 'viewer_count';
    $delete = $_GET['delete'];
    $wpdb->query("DELETE FROM $db_table_name WHERE pageid = $delete");// delete query 
    echo "<script>location.replace('admin.php?page=viewer-count');</script>";
    
  }
 // edit data in database
  if (isset($_POST['data_update_in_database'])) {
    global $wpdb; 
     $db_table_name = $wpdb->prefix . 'viewer_count';
    $edit = $_POST['edit'];
    $viewer = $_POST['viewer'];
    $counrty = $_POST['country'];
    $city = $_POST['city'];

    $wpdb->query("updat into $db_table_name set viewer='$viewer',country='$country',city='$city' WHERE pageid = $edit");
    echo "<script>location.replace('admin.php?page=viewer-count');</script>";
  }
?>
<html>
<head>
    <title>
    </title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</head>
<body>
    <table class="table text-center mt-3">
        <tr>
            <th>PAGE ID</th>
            <th>PAGE TITLE</th>
            <th>VIEWER</th>
            <th>COUNTRY</th>
            <th>CITY</th>
            <th>ZIP</th>
            <th>IP ADRESS</th>
            <th>ACTION</th>
        </tr>
        <?php
        // select all data into database
        global $wpdb; 
        $db_table_name = $wpdb->prefix . 'viewer_count';
        $result = $wpdb->get_results("SELECT * FROM $db_table_name");
        if($result){
        foreach ($result as $print) {
     echo"<tr>
                <td>$print->pageid</td>
                <td>$print->pagetitle</td>
                <td>$print->viewer</td>
                <td>$print->country</td>
                <td>$print->city</td>
                <td>$print->zip</td>
                <td>$print->ipaddress</td>
                <td><a href='admin.php?page=viewer-count&edit=$print->id'><button type='button' class='btn btn-success showdiv'>Edit</button></a><a href='admin.php?page=viewer-count&del=$print->id'><button type='button' class='btn btn-success ml-3' >Delete</button></a></td>
            </tr>";
        }}else{
            echo "<tr>
                    No Recoured Found
                    </tr>";
        }?>
    </table>
    <div id="model">
        <div id="model-edit"  class="form-group">
        <div id="close">X</div>
            <form method='post' action="<?php echo admin_url('admin-post.php'); ?>" enctype="from/data">
                <?php
                 global $wpdb; 
                 $db_table_name = $wpdb->prefix . 'viewer_count';
                 $result = $wpdb->get_results("SELECT * FROM $db_table_name");
                 if($result){
                 foreach ($result as $print) {
                echo "
                <div class='form-group row'>
                <label for='pageid' class='col-sm-3 col-form-label'>PAGE ID</label>
                <div class='col-sm-9'>
                  <input type='text' value='$print->pageid' disabled class='form-control' >
                  <input type='text' value='$print->id' name='stid' hidden class='form-control' >
                </div>
              </div>
              <div class='form-group row'>
                <label for='pagetitle' class='col-sm-3 col-form-label'>PAGE TITLE</label>
                <div class='col-sm-9'>
                  <input type='text' class='form-control' name='sttitle' value='$print->pagetitle'  >
                </div>
              </div>
              <div class='form-group row'>
                <label for='viewer' class='col-sm-3 col-form-label'>VIEWER</label>
                <div class='col-sm-9'>
                  <input type='text' class='form-control' name='stviewer' value='$print->viewer'  >
                </div>
              </div>
              <div class='form-group row'>
                <label for='country' class='col-sm-3  ' col-form-label'>COUNTRY</label>
                <div class='col-sm-9'>
                  <input type='' class='form-control' name='stcountry'  value='$print->country'   s>
                </div>
              </div>
              <div class='form-group row'>
                <label for='city' class='col-sm-3 col-form-label'>CITY</label>
                <div class='col-sm-9'>
                  <input type='text' class='form-control'  name='stcity' value='$print->city'  s>
                </div>
              </div>
              <div class='form-group row'>
                <label for='zip' class='col-sm-3 col-form-label'>ZIP</label>
                <div class='col-sm-9'>
                  <input type='text' class='form-control'  name='stzip'  value='$print->zip'   disabled s>
                </div>
              </div>
              <div class='form-group row'>
                <label for='ipaddress' class='col-sm-3 col-form-label'>IP ADDRESS</label>
                <div class='col-sm-9'>
                  <input type='text' class='form-control' name='stipaddress'  value='$print->ipaddress'  disabled>
                </div>
              </div>


                    <button type='submit' class='btn btn-success' name='dataupdatedatabase' style='margin-left:140px;'>UPDATE</button>";
                 }}?>
            </form>
        </div>
    </div>
</body>
</html>
