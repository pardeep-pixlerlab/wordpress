<?php
// silence is gollde key